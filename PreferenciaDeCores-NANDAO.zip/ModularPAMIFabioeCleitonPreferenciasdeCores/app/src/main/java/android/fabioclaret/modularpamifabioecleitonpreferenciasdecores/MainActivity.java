package android.fabioclaret.modularpamifabioecleitonpreferenciasdecores;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Layout;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button cor1, cor2, cor3, cor4, cor5, btn_trocar;
    LinearLayout tela;
    String cor = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        initComponents();

        btn_trocar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!cor.isEmpty()){
                    tela.setBackgroundColor(Color.parseColor(cor));
                }

            }
        });

        cor1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarCor(cor);
                cor = "#09A3E9";


            }
        });

        cor2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarCor(cor);
                cor = "#AC87EF";


            }
        });

        cor3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarCor(cor);
                cor = "#97C864";


            }
        });

        cor4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarCor(cor);
                cor = "#62D9CF";


            }
        });

        cor5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarCor(cor);
                cor = "#2196F3";


            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void salvarCor(String cor) {

    }

    private void initComponents() {
        cor1 = findViewById(R.id.cor1);
        cor2 = findViewById(R.id.cor2);
        cor3 = findViewById(R.id.cor3);
        cor4 = findViewById(R.id.cor4);
        cor5 = findViewById(R.id.cor5);
        btn_trocar = findViewById(R.id.btn_trocar);
        tela = findViewById(R.id.main);

    }
}